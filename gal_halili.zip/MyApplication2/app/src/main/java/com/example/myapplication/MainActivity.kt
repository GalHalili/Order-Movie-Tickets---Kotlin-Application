package com.example.myapplication

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.animation.AnimationUtils
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val posterCv = findViewById<CardView>(R.id.poster_cv)
        val anim = android.view.animation.AnimationUtils.loadAnimation(
            applicationContext,
            R.anim.img_poster_animation
        )
        posterCv.startAnimation(anim)


        val posterImg = findViewById<ImageView>(R.id.poster_img)
        val animDrawable: AnimationDrawable = posterImg.drawable as AnimationDrawable
        animDrawable.start()


        var theatreName = ""
        val youChoseStr = getString(R.string.you_chose)
        val chosenTheatreStr = getString(R.string.chosen_theatre)
        val chosenTheatreTV = findViewById<TextView>(R.id.theatre_tv)
        val theatreBtn =
            findViewById<com.google.android.material.button.MaterialButton>(R.id.theatre_btn)
        theatreBtn.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            val theatreDialogView = layoutInflater.inflate(R.layout.theatre_dialog_layout, null)
            val chosenTheatreTVInDialog = theatreDialogView.findViewById<TextView>(R.id.chosen_theatre_tv)

            theatreDialogView.findViewById<ImageButton>(R.id.cinema_city_beerSheva_btn)
                .setOnClickListener {
                    theatreName = getString(R.string.cinema_city_beer_sheva)
                    chosenTheatreTVInDialog.text = youChoseStr + " " + theatreName
                    chosenTheatreTV.text = chosenTheatreStr + ": " + theatreName
                }

            theatreDialogView.findViewById<ImageButton>(R.id.cinema_city_rishon_btn)
                .setOnClickListener {
                    theatreName = getString(R.string.cinema_city_rishon_lezion)
                    chosenTheatreTVInDialog.text = youChoseStr + " " + theatreName
                    chosenTheatreTV.text = chosenTheatreStr + ": " + theatreName
                }

            theatreDialogView.findViewById<ImageButton>(R.id.yes_planet_beerSheva_btn)
                .setOnClickListener {
                    theatreName = getString(R.string.yes_planet_beer_sheva)
                    chosenTheatreTVInDialog.text = youChoseStr + " " + theatreName
                    chosenTheatreTV.text = chosenTheatreStr + ": " + theatreName
                }

            theatreDialogView.findViewById<ImageButton>(R.id.yes_planet_rishon_btn)
                .setOnClickListener {
                    theatreName = getString(R.string.yes_planet_rishon_lezion)
                    chosenTheatreTVInDialog.text = youChoseStr + " " + theatreName
                    chosenTheatreTV.text = chosenTheatreStr + ": " + theatreName
                }

            builder.setView(theatreDialogView)
            builder.show()
        }

        var chosenDate = ""
        val chosenDateTV = findViewById<TextView>(R.id.date_tv)
        val dateBtn = findViewById<com.google.android.material.button.MaterialButton>(R.id.date_dialog_btn)
        dateBtn.setOnClickListener {
            val calender = Calendar.getInstance()
            val listener = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                chosenDate = "$dayOfMonth/${month + 1}/$year"
                chosenDateTV.text = getString(R.string.chosen_date) + ": $chosenDate"
            }
            val dateDialog = DatePickerDialog(
                this,
                R.style.CustomDatePickerTheme,
                listener,
                calender.get(Calendar.YEAR),
                calender.get(Calendar.MONTH),
                calender.get(Calendar.DAY_OF_MONTH)
            )

            dateDialog.datePicker.minDate = calender.timeInMillis
            dateDialog.show()
        }


        val totalPriceTv = findViewById<TextView>(R.id.total_price_tv)
        val childSp = findViewById<Spinner>(R.id.child_tickets_spinner)
        val adultSp = findViewById<Spinner>(R.id.adult_tickets_spinner)

        val ticketsNumberArray = (0..10).toList()
        var selectedChildTicketAmount = 0
        var selectedAdultTicketAmount = 0
        var childTotalPrice = 0
        var adultTotalPrice = 0
        var totalPrice = 0
        val coinStr = getString(R.string.coin)
        val childTicketPrice = 15
        val adultTicketPrice = 35
        var isChildSpinnerInitialized = false // Flag for child spinner
        var isAdultSpinnerInitialized = false // Flag for adult spinner

        // Create an ArrayAdapter using the numbers array
        val arrayAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            ticketsNumberArray
        )

        // Set the drop-down view resource for the adapter
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Attach the adapter to the Spinner
        childSp.adapter = arrayAdapter
        adultSp.adapter = arrayAdapter

        childSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val childSpinnerInput = parent.getItemAtPosition(position) as Int
                selectedChildTicketAmount = childSpinnerInput
                childTotalPrice = selectedChildTicketAmount * childTicketPrice
                totalPrice = childTotalPrice + adultTotalPrice
                totalPriceTv.text = getString(R.string.total_price) + " $totalPrice $coinStr"

                // Display the toast only if the child spinner has been initialized
                if (isChildSpinnerInitialized) {
                    val toastTxt = getString(R.string.you_have_chosen) + " $selectedChildTicketAmount " + getString(
                        R.string.children_tickets
                    )
                    Toast.makeText(this@MainActivity, toastTxt, Toast.LENGTH_LONG).show()
                } else {
                    isChildSpinnerInitialized = true // Set the flag to true after first initialization
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }

        adultSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val adultSpinnerInput = parent.getItemAtPosition(position) as Int
                selectedAdultTicketAmount = adultSpinnerInput
                adultTotalPrice = selectedAdultTicketAmount * adultTicketPrice
                totalPrice = childTotalPrice + adultTotalPrice
                totalPriceTv.text = getString(R.string.total_price) + " $totalPrice $coinStr"

                // Display the toast only if the adult spinner has been initialized
                if (isAdultSpinnerInitialized) {
                    val toastTxt = getString(R.string.you_have_chosen) + " $selectedAdultTicketAmount " + getString(
                        R.string.adult_tickets
                    )
                    Toast.makeText(this@MainActivity, toastTxt, Toast.LENGTH_LONG).show()
                } else {
                    isAdultSpinnerInitialized = true // Set the flag to true after first initialization
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }


        val getTicketsBtn = findViewById<Button>(R.id.get_tickets_btn)
        getTicketsBtn.setOnClickListener {
            when {
                chosenDate == "" -> {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.no_date_has_been_selected), Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener // Exit the lambda function if no date is selected
                }

                theatreName == "" -> {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.no_theatre_has_been_selected), Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener // Exit the lambda function if no theater is selected
                }

                totalPrice == 0 -> {
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.no_ticket_was_selected), Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener // Exit the lambda function if no ticket was selected
                }
            }

            // Create an instance of the AlertDialog.Builder for the order information dialog
            val orderInfoDialogBuilder = AlertDialog.Builder(this, R.style.CustomDatePickerTheme)


            orderInfoDialogBuilder.apply {
                setTitle(getString(R.string.order_information))
                setMessage(
                    getString(R.string.you_chose_to_watch_the_lion_king_on_date) + " $chosenDate" +
                    getString(R.string.in_theater) + " $theatreName.\n" +
                    getString(R.string.your_order_includes) + " $selectedChildTicketAmount " +
                    getString(R.string.children_s_tickets_and) + " $selectedAdultTicketAmount " +
                    getString(R.string.adult_tickets) + ".\n"+
                    getString(R.string.the_total_price_of_the_order_is) + " $totalPrice $coinStr"
                )
                setIcon(R.drawable.info_outline)


                // Set up the positive button click listener
                setPositiveButton(getString(R.string.confirm_purchase)) { dialog, which ->
                    val confirmDialogView = layoutInflater.inflate(R.layout.order_confirmation_dialog, null)

                    // Create a new AlertDialog.Builder for the order confirmation dialog
                    val confirmDialogBuilder = AlertDialog.Builder(this@MainActivity, R.style.CustomConfirmationDialogStyle)

                    // Set the view for the order confirmation dialog
                    confirmDialogBuilder.setView(confirmDialogView)

                    // Access the TextView order_info_tv from the inflated layout
                    val orderInfoTv = confirmDialogView.findViewById<TextView>(R.id.order_info_tv)

                    // Set the text dynamically
                    orderInfoTv.text =
                        getString(R.string.date) + " $chosenDate\n" +
                        getString(R.string.theatre) + " $theatreName\n" +
                        getString(R.string.children) + " $selectedChildTicketAmount, " + getString(R.string.Adult) + " $selectedAdultTicketAmount\n" +
                        getString(R.string.total_price) + " $totalPrice $coinStr"

                    // Show the order confirmation dialog
                    confirmDialogBuilder.show()

                    //Clear the activity from the last order information
                    chosenDateTV.text = ""
                    chosenTheatreTV.text = ""
                    childSp.setSelection(0)
                    adultSp.setSelection(0)
                }

                // Add a neutral button to handle cancel action
                setNeutralButton(getString(R.string.cancel)) { dialog, which ->
                }

                // Show the order information dialog
                show()
            }
        }
    }
}